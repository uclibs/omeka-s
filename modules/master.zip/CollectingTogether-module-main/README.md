# Collecting Together

This Omeka S module enables functionality needed for the Collecting Together project.

When cloning this repository remember to rename the directory from "CollectingTogether-module" to "CollectingTogether".
